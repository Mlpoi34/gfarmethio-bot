import os
import json
import logging
from telegram import Update, ReplyKeyboardMarkup, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ContextTypes,
    filters,
)

# === Configuration ===
TOKEN = '8597916092:AAEcJE5CdT0ptTHDTkKx3rKu8zRE4Z2WbxI'  # Replace with your bot token
USER_DATA_FILE = 'user_data.json'
TASKS_FILE = 'tasks.json'
TUTORIAL_FILE = 'tutorial.mp4'

# === Logging ===
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    level=logging.INFO)
logger = logging.getLogger(__name__)

# === Data Persistence ===
# Load or initialize user data from JSON
if os.path.exists(USER_DATA_FILE):
    with open(USER_DATA_FILE, 'r') as f:
        user_data = json.load(f)
else:
    user_data = {}
# Load tasks (static list of dicts with first/last/email/password)
if os.path.exists(TASKS_FILE):
    with open(TASKS_FILE, 'r') as f:
        tasks = json.load(f)
else:
    tasks = [
        {"first_name": "Alice", "last_name": "Smith", "email": "alice@example.com", "password": "pass123"},
        {"first_name": "Bob",   "last_name": "Jones", "email": "bob@example.com",   "password": "qwerty"},
        # ... more tasks ...
    ]

def save_user_data():
    """Save the user_data dictionary to file."""
    try:
        with open(USER_DATA_FILE, 'w') as f:
            json.dump(user_data, f, indent=4)
    except Exception as e:
        logger.error(f"Error saving user data: {e}")

def init_user(user_id: str, user_info: dict):
    """Ensure all expected fields exist for this user."""
    if user_id not in user_data:
        # Initialize a new record
        user_data[user_id] = {
            "first_name": user_info.get("first_name", ""),
            "last_name":  user_info.get("last_name", ""),
            "referrer":   None,
            "referrals":  [],
            "referred_count": 0,
            "task_index": 0,
            "tasks_done": 0,
            "hold_balance": 0,
            "balance": 0,
            "tutorial_sent": False
        }
    else:
        # Ensure defaults exist (for backward compatibility)
        defaults = {
            "referrer":   None,
            "referrals":  [],
            "referred_count": 0,
            "task_index": 0,
            "tasks_done": 0,
            "hold_balance": 0,
            "balance": 0,
            "tutorial_sent": False
        }
        for key, val in defaults.items():
            user_data[user_id].setdefault(key, val)

# === Handlers ===
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /start (check for optional referral ID)."""
    user = update.effective_user
    user_id = str(user.id)
    init_user(user_id, user.to_dict())
    # Handle referral link
    if context.args:
        ref_id = context.args[0]
        if ref_id.isdigit() and ref_id in user_data and ref_id != user_id:
            if user_data[user_id]["referrer"] is None:
                user_data[user_id]["referrer"] = ref_id
                user_data[ref_id]["referrals"].append(user_id)
                user_data[ref_id]["referred_count"] = len(user_data[ref_id]["referrals"])
    save_user_data()
    # Show main menu
    keyboard = [["Tasks", "Balance/Payout"], ["Referral", "Tutorial"]]
    reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
    await update.message.reply_text("Welcome! Choose an option:", reply_markup=reply_markup)

async def show_tasks(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show the current task with a 'Done' button."""
    user = update.effective_user
    user_id = str(user.id)
    init_user(user_id, user.to_dict())
    index = user_data[user_id]["task_index"]
    if index >= len(tasks):
        await update.message.reply_text("You have completed all tasks!")
        return
    task = tasks[index]
    text = (f"Task {index+1}/{len(tasks)}:\n"
            f"First Name: {task['first_name']}\n"
            f"Last Name: {task['last_name']}\n"
            f"Email: {task['email']}\n"
            f"Password: {task['password']}")
    button = InlineKeyboardButton("Done", callback_data="task_done")
    reply_markup = InlineKeyboardMarkup([[button]])
    await update.message.reply_text(text, reply_markup=reply_markup)
    save_user_data()

async def task_done(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Callback when user presses 'Done' on a task."""
    query = update.callback_query
    await query.answer()
    user = query.from_user
    user_id = str(user.id)
    init_user(user_id, user.to_dict())
    idx = user_data[user_id]["task_index"]
    if idx < len(tasks):
        user_data[user_id]["tasks_done"] += 1
        user_data[user_id]["task_index"] += 1
        user_data[user_id]["hold_balance"] += 31  # add ETB to hold
        save_user_data()
        await query.edit_message_text("Task marked done. 31 ETB added to hold balance.")
        # Send next task if any
        new_idx = user_data[user_id]["task_index"]
        if new_idx < len(tasks):
            next_task = tasks[new_idx]
            text = (f"Task {new_idx+1}/{len(tasks)}:\n"
                    f"First Name: {next_task['first_name']}\n"
                    f"Last Name: {next_task['last_name']}\n"
                    f"Email: {next_task['email']}\n"
                    f"Password: {next_task['password']}")
            button = InlineKeyboardButton("Done", callback_data="task_done")
            await context.bot.send_message(chat_id=query.message.chat_id, text=text,
                                           reply_markup=InlineKeyboardMarkup([[button]]))
        else:
            await context.bot.send_message(chat_id=query.message.chat_id, text="You have completed all tasks!")
    else:
        await query.edit_message_text("No more tasks available.")
        save_user_data()

async def show_balance(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Display hold and main balances."""
    user = update.effective_user
    user_id = str(user.id)
    init_user(user_id, user.to_dict())
    hold = user_data[user_id]["hold_balance"]
    bal  = user_data[user_id]["balance"]
    await update.message.reply_text(
        f"Hold Balance: {hold} ETB\n"
        f"Main Balance: {bal} ETB\n\n"
        "To request a payout, use /payout <phone> <amount>.")

async def payout_request(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /payout <phone> <amount>."""
    user = update.effective_user
    user_id = str(user.id)
    init_user(user_id, user.to_dict())
    args = context.args
    if len(args) != 2:
        await update.message.reply_text("Usage: /payout <phone> <amount>")
        return
    phone = args[0]
    try:
        amount = float(args[1])
    except ValueError:
        await update.message.reply_text("Amount must be a number.")
        return
    if amount > user_data[user_id]["balance"]:
        await update.message.reply_text("Insufficient main balance.")
        return
    user_data[user_id]["balance"] -= amount
    save_user_data()
    await update.message.reply_text(f"Payout {amount} ETB to {phone} requested.")

async def show_referral(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show referral link and count."""
    user = update.effective_user
    user_id = str(user.id)
    init_user(user_id, user.to_dict())
    bot_user = await context.bot.get_me()
    bot_username = bot_user.username or ""
    link = f"https://t.me/{bot_username}?start={user_id}"
    count = user_data[user_id]["referred_count"]
    await update.message.reply_text(f"Your referral link: {link}\nTotal referred: {count}")

async def send_tutorial(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send tutorial video once."""
    user = update.effective_user
    user_id = str(user.id)
    init_user(user_id, user.to_dict())
    if user_data[user_id]["tutorial_sent"]:
        await update.message.reply_text("Tutorial already sent.")
        return
    user_data[user_id]["tutorial_sent"] = True
    save_user_data()
    if os.path.exists(TUTORIAL_FILE):
        with open(TUTORIAL_FILE, 'rb') as vid:
            await update.message.reply_video(vid)
    else:
        await update.message.reply_text("Tutorial video not available.")

async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Log and report errors."""
    logger.error("Exception while handling an update:", exc_info=context.error)
    try:
        if isinstance(update, Update) and update.effective_message:
            await update.effective_message.reply_text("An unexpected error occurred.")
    except Exception as e:
        logger.error(f"Failed to send error message: {e}")

def main() -> None:
    """Start the bot."""
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.Regex("^Tasks$"), show_tasks))
    app.add_handler(CallbackQueryHandler(task_done, pattern="task_done"))
    app.add_handler(MessageHandler(filters.Regex("^Balance/Payout$"), show_balance))
    app.add_handler(CommandHandler("payout", payout_request))
    app.add_handler(MessageHandler(filters.Regex("^Referral$"), show_referral))
    app.add_handler(MessageHandler(filters.Regex("^Tutorial$"), send_tutorial))
    app.add_error_handler(error_handler)
    app.run_polling()

if __name__ == '__main__':
    main()
