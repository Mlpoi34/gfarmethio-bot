#!/usr/bin/env python3
"""
gfarmethio_bot.py
Single-file Telegram bot (manual-approval + hold + referrals + withdrawals + admin UI)
Requirements:
  - Python 3.9+
  - python-telegram-bot (v20/v22). If you use JobQueue extras: pip install "python-telegram-bot[job-queue]"
Usage:
  export TELEGRAM_BOT_TOKEN="..." 
  export ADMIN_ID="12345678"
  python gfarmethio_bot.py
"""

import os
import json
import logging
import time
import uuid
from datetime import datetime, timezone, timedelta
from typing import Dict, Any, List

from telegram import (
    Update,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    ReplyKeyboardMarkup,
)
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ContextTypes,
    filters,
)

# ---------------- CONFIG ----------------
TOKEN = "8597916092:AAEcJE5CdT0ptTHDTkKx3rKu8zRE4Z2WbxI"
if not TOKEN:
    raise RuntimeError("TELEGRAM_BOT_TOKEN environment variable is not set.")

ADMIN_ID = "5535222774"
if not ADMIN_ID:
    raise RuntimeError("ADMIN_ID environment variable is not set.")
ADMIN_ID = str(int(ADMIN_ID))

DATA_FILE = "bot_data.json"
BACKUP_DIR = "backups"
MAX_BACKUPS = 5

# Production hold is 3 days; for testing change TEST_MODE True
TEST_MODE = False
HOLD_SECONDS = 10 if TEST_MODE else 3 * 24 * 3600
HOLD_CHECK_INTERVAL = 10 if TEST_MODE else 3600  # seconds

REFERRAL_PERCENT = 0.10
MIN_WITHDRAW = 1.0  # minimal allowed withdraw (adjust)

# Reply keyboard (bottom menu)
MENU_KEYBOARD = ReplyKeyboardMarkup(
    [
        ["Tasks", "Balance", "Submit Task"],
        ["Withdraw", "Tutorial", "Referral"],
        ["Help"]
    ],
    resize_keyboard=True,
)

# ---------------- Logging ----------------
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO
)
logger = logging.getLogger(__name__)

# ---------------- Data ----------------
DEFAULT_DATA = {
    "users": {},         # user_id -> user record
    "tasks": {},         # task_id -> task
    "submissions": {},   # submission_id -> submission
    "holds": {},         # hold_id -> hold
    "withdrawals": {},   # request_id -> withdrawal
    "audit": [],         # list of events
}
_data: Dict[str, Any] = {}

# ---------------- Persistence ----------------
def load_data():
    global _data
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                _data = json.load(f)
        except Exception:
            logger.exception("Failed to load data file; starting fresh.")
            _data = DEFAULT_DATA.copy()
    else:
        _data = DEFAULT_DATA.copy()

def save_data():
    # atomic-ish write: write tmp then replace
    tmp = DATA_FILE + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(_data, f, indent=2, ensure_ascii=False)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, DATA_FILE)
    except Exception as e:
        logger.exception("Failed to save data: %s", e)
        # backup attempt
        try:
            os.makedirs(BACKUP_DIR, exist_ok=True)
            ts = datetime.utcnow().strftime("%Y%m%d%H%M%S")
            with open(os.path.join(BACKUP_DIR, f"backup_{ts}.json"), "w", encoding="utf-8") as fb:
                json.dump(_data, fb, indent=2, ensure_ascii=False)
        except Exception:
            logger.exception("Backup also failed.")

def audit(event: str, actor: str, details: dict = None):
    _data.setdefault("audit", []).append({
        "id": str(uuid.uuid4()),
        "ts": int(time.time()),
        "actor": actor,
        "event": event,
        "details": details or {}
    })
    save_data()

# ---------------- Helpers ----------------
def uid_key(uid: int) -> str:
    return str(uid)

def ensure_user(user) -> str:
    uid = uid_key(user.id)
    users = _data.setdefault("users", {})
    if uid not in users:
        users[uid] = {
            "telegram_id": uid,
            "first_name": user.first_name or "",
            "last_name": user.last_name or "",
            "username": user.username or "",
            "referrer": None,
            "referrals": [],
            "referred_count": 0,
            "balance": 0.0,
            "holds": [],         # list of hold_ids
            "statistics": {"submitted": 0, "approved": 0, "rejected": 0},
            "pending_withdraw": None,  # amount waiting for method
        }
        audit("user_created", uid, {"name": users[uid]["first_name"]})
        save_data()
    return uid

def create_task(title: str, reward: float, description: str, creator: str) -> str:
    task_id = str(uuid.uuid4())
    _data.setdefault("tasks", {})[task_id] = {
        "task_id": task_id,
        "title": title,
        "reward": float(reward),
        "description": description,
        "published": True,
        "created_by": creator,
        "created_at": int(time.time()),
    }
    audit("task_created", creator, {"task_id": task_id, "title": title})
    save_data()
    return task_id

def create_submission(user_id: str, task_id: str, evidence: dict) -> str:
    sub_id = str(uuid.uuid4())
    _data.setdefault("submissions", {})[sub_id] = {
        "submission_id": sub_id,
        "user_id": user_id,
        "task_id": task_id,
        "evidence": evidence,
        "status": "pending",
        "admin_note": None,
        "created_at": int(time.time()),
        "decision_at": None,
    }
    _data["users"][user_id]["statistics"]["submitted"] = _data["users"][user_id]["statistics"].get("submitted", 0) + 1
    audit("submission_created", user_id, {"submission_id": sub_id, "task_id": task_id})
    save_data()
    return sub_id

def create_hold(user_id: str, amount: float, origin_submission_id: str = None) -> str:
    hid = str(uuid.uuid4())
    now = int(time.time())
    _data.setdefault("holds", {})[hid] = {
        "hold_id": hid,
        "user_id": user_id,
        "amount": float(amount),
        "origin_submission_id": origin_submission_id,
        "created_at": now,
        "release_at": now + HOLD_SECONDS,
        "status": "pending",
    }
    _data["users"][user_id]["holds"].append(hid)
    audit("hold_created", ADMIN_ID, {"hold_id": hid, "user": user_id, "amount": amount})
    save_data()
    return hid

def release_due_holds():
    now = int(time.time())
    changed = False
    for hid, hold in list(_data.get("holds", {}).items()):
        if hold["status"] == "pending" and hold["release_at"] <= now:
            uid = hold["user_id"]
            _data["users"][uid]["balance"] += hold["amount"]
            hold["status"] = "released"
            hold["released_at"] = now
            audit("hold_released", "system", {"hold_id": hid, "user": uid, "amount": hold["amount"]})
            changed = True
    if changed:
        save_data()
    return changed

def create_withdrawal_request(user_id: str, amount: float, method_text: str) -> str:
    bal = _data["users"][user_id]["balance"]
    if amount <= 0 or amount > bal:
        raise ValueError("Invalid amount or insufficient balance")
    reqid = str(uuid.uuid4())
    _data.setdefault("withdrawals", {})[reqid] = {
        "request_id": reqid,
        "user_id": user_id,
        "amount": float(amount),
        "method": method_text,
        "status": "pending",
        "created_at": int(time.time()),
        "processed_at": None,
        "admin_note": None,
        "tx_reference": None,
    }
    audit("withdrawal_requested", user_id, {"request_id": reqid, "amount": amount})
    save_data()
    return reqid

def mark_withdrawal_paid(request_id: str, tx_ref: str = None) -> bool:
    req = _data.get("withdrawals", {}).get(request_id)
    if not req or req["status"] != "pending":
        return False
    uid = req["user_id"]
    amt = req["amount"]
    if _data["users"][uid]["balance"] < amt:
        return False
    _data["users"][uid]["balance"] -= amt
    req["status"] = "paid"
    req["processed_at"] = int(time.time())
    req["tx_reference"] = tx_ref or "manual"
    audit("withdrawal_paid", ADMIN_ID, {"request_id": request_id, "tx": req["tx_reference"]})
    save_data()
    return True

# ---------------- Bot handlers ----------------
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    uid = ensure_user(user)
    # handle deep-link referrer
    if context.args:
        r = context.args[0]
        if r.isdigit() and r in _data.get("users", {}) and r != uid:
            if _data["users"][uid].get("referrer") is None:
                _data["users"][uid]["referrer"] = r
                _data["users"][r]["referrals"].append(uid)
                _data["users"][r]["referred_count"] = _data["users"][r].get("referred_count", 0) + 1
                audit("referral_used", uid, {"ref": r})
                save_data()
    # show toggle menu
    await update.message.reply_text("Toggle the Menu: Use the buttons below 👇", reply_markup=MENU_KEYBOARD)

async def show_tasks(update: Update, context: ContextTypes.DEFAULT_TYPE):
    ensure_user(update.effective_user)
    tasks = _data.get("tasks", {})
    published = [t for t in tasks.values() if t.get("published", True)]
    if not published:
        await update.message.reply_text("No tasks right now.")
        return
    text_lines = []
    for i, t in enumerate(published, start=1):
        text_lines.append(f"{i}. {t['title']} — Reward: {t['reward']}\n{t['description']}")
    text = "\n\n".join(text_lines)
    text += "\n\nTo submit: /submit <task_number>"
    await update.message.reply_text(text)

async def submit_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    uid = ensure_user(user)
    args = context.args
    tasks_list = [t for t in _data.get("tasks", {}).values() if t.get("published", True)]
    if not args:
        await update.message.reply_text("Usage: /submit <task_number>")
        return
    try:
        idx = int(args[0]) - 1
        if idx < 0 or idx >= len(tasks_list):
            raise ValueError
    except Exception:
        await update.message.reply_text("Invalid task number.")
        return
    task = tasks_list[idx]
    # For simplicity we accept optional evidence text after the number
    evidence_text = " ".join(args[1:]) if len(args) > 1 else ""
    # Create submission and notify admin (admin receives buttons to approve/reject)
    sub_id = create_submission(uid, task["task_id"], {"text": evidence_text})
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("Approve", callback_data=f"approve_sub:{sub_id}"),
         InlineKeyboardButton("Reject", callback_data=f"reject_sub:{sub_id}")],
    ])
    await context.bot.send_message(int(ADMIN_ID),
                                   f"New submission {sub_id[:8]}\nUser: {uid}\nTask: {task['title']}\nEvidence: {evidence_text}",
                                   reply_markup=kb)
    await update.message.reply_text("✅ Submission received, pending admin review.")

async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data
    # Approve submission
    if data.startswith("approve_sub:"):
        sub_id = data.split(":", 1)[1]
        sub = _data.get("submissions", {}).get(sub_id)
        if not sub or sub["status"] != "pending":
            await query.edit_message_text("Submission not found or already processed.")
            return
        task = _data["tasks"].get(sub["task_id"])
        if not task:
            await query.edit_message_text("Original task missing.")
            return
        # create hold for submitter
        hold_id = create_hold(sub["user_id"], task["reward"], origin_submission_id=sub_id)
        # referral
        ref = _data["users"][sub["user_id"]].get("referrer")
        ref_hold_id = None
        if ref:
            ref_amount = round(task["reward"] * REFERRAL_PERCENT, 2)
            ref_hold_id = create_hold(ref, ref_amount, origin_submission_id=sub_id)
        # update submission
        sub["status"] = "approved"
        sub["decision_at"] = int(time.time())
        sub["admin_note"] = f"approved by {ADMIN_ID}"
        _data["users"][sub["user_id"]]["statistics"]["approved"] = _data["users"][sub["user_id"]]["statistics"].get("approved", 0) + 1
        save_data()
        await query.edit_message_text("Submission approved — hold created.")
        # notify user & referrer
        release_dt = datetime.fromtimestamp(_data["holds"][hold_id]["release_at"], tz=timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
        await context.bot.send_message(int(sub["user_id"]), f"✅ Your submission was approved. {task['reward']} is on hold and will release at {release_dt}.")
        if ref_hold_id:
            await context.bot.send_message(int(ref), f"🎉 You earned a referral bonus of {_data['holds'][ref_hold_id]['amount']} (on hold).")
        audit("submission_approved", ADMIN_ID, {"submission": sub_id, "hold": hold_id, "ref_hold": ref_hold_id})
        return

    if data.startswith("reject_sub:"):
        sub_id = data.split(":", 1)[1]
        sub = _data.get("submissions", {}).get(sub_id)
        if not sub or sub["status"] != "pending":
            await query.edit_message_text("Submission not found or already processed.")
            return
        sub["status"] = "rejected"
        sub["decision_at"] = int(time.time())
        sub["admin_note"] = f"rejected by {ADMIN_ID}"
        _data["users"][sub["user_id"]]["statistics"]["rejected"] = _data["users"][sub["user_id"]]["statistics"].get("rejected", 0) + 1
        save_data()
        await query.edit_message_text("Submission rejected.")
        await context.bot.send_message(int(sub["user_id"]), "❌ Your submission was rejected by admin.")
        audit("submission_rejected", ADMIN_ID, {"submission": sub_id})
        return

    # Admin: mark withdrawal paid
    if data.startswith("withdraw_paid:"):
        reqid = data.split(":", 1)[1]
        ok = mark_withdrawal_paid(reqid, tx_ref="manual")
        if ok:
            await query.edit_message_text("Marked as PAID and user balance deducted.")
            req = _data["withdrawals"][reqid]
            await context.bot.send_message(int(req["user_id"]), f"💸 Your withdrawal {reqid[:8]} was marked PAID by admin.")
        else:
            await query.edit_message_text("Failed to mark paid (maybe insufficient balance).")
        return

    if data.startswith("withdraw_reject:"):
        reqid = data.split(":", 1)[1]
        req = _data.get("withdrawals", {}).get(reqid)
        if not req or req["status"] != "pending":
            await query.edit_message_text("Request not found or already processed.")
            return
        req["status"] = "rejected"
        req["processed_at"] = int(time.time())
        req["admin_note"] = f"rejected by {ADMIN_ID}"
        save_data()
        await query.edit_message_text("Withdrawal rejected.")
        await context.bot.send_message(int(req["user_id"]), f"❌ Your withdrawal {reqid[:8]} was rejected by admin.")
        audit("withdrawal_rejected", ADMIN_ID, {"request": reqid})
        return

async def balance_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = ensure_user(update.effective_user)
    user = _data["users"][uid]
    pending = sum(_data["holds"][hid]["amount"] for hid in user.get("holds", []) if _data["holds"][hid]["status"] == "pending")
    await update.message.reply_text(f"Balance: {user['balance']:.2f}\nOn hold: {pending:.2f}")

async def withdraw_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = ensure_user(update.effective_user)
    args = context.args
    if not args:
        await update.message.reply_text("Usage: /withdraw <amount>\nThen send method (phone/wallet) as a message.")
        return
    try:
        amount = float(args[0])
    except Exception:
        await update.message.reply_text("Invalid amount.")
        return
    if amount < MIN_WITHDRAW:
        await update.message.reply_text(f"Minimum withdraw: {MIN_WITHDRAW}")
        return
    if amount > _data["users"][uid]["balance"]:
        await update.message.reply_text("Insufficient balance.")
        return
    # store pending amount and ask for method
    _data["users"][uid]["pending_withdraw"] = amount
    save_data()
    await update.message.reply_text("Send method details now (e.g., Telebirr phone or wallet address).")

async def generic_message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (update.message.text or "").strip()
    uid = ensure_user(update.effective_user)
    # If user has pending withdraw amount, treat this message as method details
    pending = _data["users"][uid].get("pending_withdraw")
    if pending:
        try:
            reqid = create_withdrawal_request(uid, float(pending), text)
        except ValueError:
            await update.message.reply_text("Invalid withdraw or insufficient balance.")
            _data["users"][uid]["pending_withdraw"] = None
            save_data()
            return
        _data["users"][uid]["pending_withdraw"] = None
        save_data()
        await update.message.reply_text("✅ Withdrawal request submitted. Admin will review and process.")
        # notify admin
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("Mark Paid", callback_data=f"withdraw_paid:{reqid}"),
             InlineKeyboardButton("Reject", callback_data=f"withdraw_reject:{reqid}")]
        ])
        await context.bot.send_message(int(ADMIN_ID),
                                       f"Withdrawal {reqid[:8]} from user {uid}\nAmount: {pending}\nMethod: {text}",
                                       reply_markup=kb)
        return

    # Menu shortcuts (text buttons)
    if text.lower() in ("tasks", "task"):
        await show_tasks(update, context)
        return
    if text.lower() in ("balance",):
        await balance_cmd(update, context)
        return
    if text.lower() in ("submit task", "submit"):
        await update.message.reply_text("To submit: /submit <task_number>")
        return
    if text.lower() in ("withdraw",):
        await update.message.reply_text("To request withdraw: /withdraw <amount>")
        return
    if text.lower() in ("referral",):
        user = _data["users"][uid]
        ref = user.get("referrer") or "None"
        await update.message.reply_text(f"Your referrer: {ref}\nShare this link to refer: t.me/yourbot?start={uid}")
        return
    if text.lower() in ("tutorial",):
        await update.message.reply_text("Tutorial: follow the steps provided by admin.")
        return
    if text.lower() in ("help",):
        await update.message.reply_text("Help: /tasks /submit /balance /withdraw. Admin: /admin")
        return

# ---------------- Admin commands ----------------
async def admin_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if str(update.effective_user.id) != ADMIN_ID:
        await update.message.reply_text("Forbidden")
        return
    total_users = len(_data.get("users", {}))
    total_balance = sum(u.get("balance", 0.0) for u in _data.get("users", {}).values())
    total_holds = sum(h.get("amount", 0.0) for h in _data.get("holds", {}).values() if h.get("status") == "pending")
    pending_subs = len([s for s in _data.get("submissions", {}).values() if s.get("status") == "pending"])
    pending_withdraws = len([w for w in _data.get("withdrawals", {}).values() if w.get("status") == "pending"])
    text = (f"Admin Dashboard\nUsers: {total_users}\nTotal balance: {total_balance:.2f}\n"
            f"Pending holds: {total_holds:.2f}\nPending submissions: {pending_subs}\nPending withdrawals: {pending_withdraws}")
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("View submissions", callback_data="admin_view_subs")],
        [InlineKeyboardButton("View withdrawals", callback_data="admin_view_withd")],
        [InlineKeyboardButton("Add task", callback_data="admin_add_task")],
    ])
    await update.message.reply_text(text, reply_markup=kb)

async def admin_callback_shortcuts(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data
    if data == "admin_view_subs":
        pending = [s for s in _data.get("submissions", {}).values() if s.get("status") == "pending"]
        if not pending:
            await query.edit_message_text("No pending submissions.")
            return
        for s in pending[:6]:
            user = _data["users"][s["user_id"]]
            task = _data["tasks"].get(s["task_id"], {"title": "?"})
            text = (f"Submission {s['submission_id'][:8]}\nUser: {user['first_name']} ({s['user_id']})\nTask: {task['title']}\nEvidence: {s['evidence'].get('text','---')}")
            kb = InlineKeyboardMarkup([
                [InlineKeyboardButton("Approve", callback_data=f"approve_sub:{s['submission_id']}"),
                 InlineKeyboardButton("Reject", callback_data=f"reject_sub:{s['submission_id']}")]
            ])
            await context.bot.send_message(int(ADMIN_ID), text, reply_markup=kb)
        await query.edit_message_text("Sent up to 6 pending submissions to admin chat.")
        return
    if data == "admin_view_withd":
        pending = [w for w in _data.get("withdrawals", {}).values() if w.get("status") == "pending"]
        if not pending:
            await query.edit_message_text("No pending withdrawals.")
            return
        for w in pending[:6]:
            user = _data["users"][w["user_id"]]
            text = f"Withdraw {w['request_id'][:8]}\nUser: {user['first_name']} ({w['user_id']})\nAmount: {w['amount']}\nMethod: {w['method']}"
            kb = InlineKeyboardMarkup([
                [InlineKeyboardButton("Mark Paid", callback_data=f"withdraw_paid:{w['request_id']}"),
                 InlineKeyboardButton("Reject", callback_data=f"withdraw_reject:{w['request_id']}")]
            ])
            await context.bot.send_message(int(ADMIN_ID), text, reply_markup=kb)
        await query.edit_message_text("Sent up to 6 pending withdrawals to admin chat.")
        return
    if data == "admin_add_task":
        await query.edit_message_text("To add a task use command:\n/addtask Title | Reward | Description")
        return

async def addtask_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if str(update.effective_user.id) != ADMIN_ID:
        await update.message.reply_text("Forbidden")
        return
    payload = " ".join(context.args) if context.args else ""
    if not payload:
        await update.message.reply_text("Usage: /addtask Title | Reward | Description")
        return
    try:
        title, reward, desc = [p.strip() for p in payload.split("|", 2)]
        reward = float(reward)
    except Exception:
        await update.message.reply_text("Bad format. Use: /addtask Title | Reward | Description")
        return
    tid = create_task(title, reward, desc, update.effective_user.username or ADMIN_ID)
    await update.message.reply_text(f"Task created: {title} ({tid[:8]})")

# ---------------- Periodic job ----------------
async def job_release(context: ContextTypes.DEFAULT_TYPE):
    changed = release_due_holds()
    if changed:
        # notify users who got releases: send messages for newly released holds
        for hid, h in _data.get("holds", {}).items():
            if h.get("status") == "released" and not h.get("notified"):
                try:
                    await context.bot.send_message(int(h["user_id"]), f"🎉 Hold released: {h['amount']:.2f} added to your balance.")
                    h["notified"] = True
                    save_data()
                except Exception:
                    pass

# ---------------- Boot ----------------
def main():
    load_data()
    app = ApplicationBuilder().token(TOKEN).build()

    # Handlers
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("tasks", lambda u,c: show_tasks(u,c)))
    app.add_handler(CommandHandler("submit", submit_cmd))
    app.add_handler(CommandHandler("balance", balance_cmd))
    app.add_handler(CommandHandler("withdraw", withdraw_cmd))
    app.add_handler(CommandHandler("admin", admin_cmd))
    app.add_handler(CommandHandler("addtask", addtask_cmd))
    app.add_handler(CallbackQueryHandler(callback_handler, pattern="^(approve_sub:|reject_sub:|withdraw_paid:|withdraw_reject:)"))
    app.add_handler(CallbackQueryHandler(admin_callback_shortcuts, pattern="^(admin_view_subs|admin_view_withd|admin_add_task)$"))
    app.add_handler(MessageHandler(filters.TEXT & (~filters.COMMAND), generic_message_handler))

    # Schedule hold release job (uses app.job_queue which exists in PTB v20/v22)
    app.job_queue.run_repeating(job_release, interval=HOLD_CHECK_INTERVAL, first=10)

    logger.info("Bot started")
    app.run_polling()

if __name__ == "__main__":
    main()
