from telegram import (
    Update,
    InlineKeyboardButton,
    InlineKeyboardMarkup
)
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    CallbackQueryHandler,
    ContextTypes
)
import time, json, os

# ================= CONFIG =================
TOKEN = "8597916092:AAHAdmniELdPVKSwgjgrCf6fQIpah4zxZaI"
ADMIN_ID = 5535222774
CHANNEL_USERNAME = "@hhrtjg"

BAL_FILE = "balances.json"
HOLD_FILE = "hold.json"
USER_FILE = "users.json"
REF_FILE = "referrals.json"

# ================= LOAD DATA =================
def load(file):
    if os.path.exists(file):
        with open(file, "r") as f:
            return json.load(f)
    return {}

balances = load(BAL_FILE)
holds = load(HOLD_FILE)
users = load(USER_FILE)
referrals = load(REF_FILE)

def save(file, data):
    with open(file, "w") as f:
        json.dump(data, f)

# ================= MAIN MENU =================
def main_menu():
    keyboard = [
        [InlineKeyboardButton("👤 My Account", callback_data="account")],
        [InlineKeyboardButton("📋 Task", callback_data="task")],
        [InlineKeyboardButton("💰 Balance", callback_data="finance")],
        [InlineKeyboardButton("👥 Referral", callback_data="referral")]
    ]
    return InlineKeyboardMarkup(keyboard)

# ================= START =================
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = str(update.effective_user.id)

    # Referral handling
    if context.args:
        ref_id = context.args[0]
        if ref_id != user_id:
            referrals[user_id] = ref_id
            save(REF_FILE, referrals)

    users[user_id] = {
        "username": update.effective_user.username
    }
    save(USER_FILE, users)

    await update.message.reply_text(
        "Welcome to the bot!",
        reply_markup=main_menu()
    )

# ================= BUTTON HANDLER =================
async def button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = str(query.from_user.id)
    await query.answer()

    # ---------- BACK ----------
    if query.data == "main":
        await query.edit_message_text(
            "Main Menu:",
            reply_markup=main_menu()
        )

    # ---------- ACCOUNT ----------
    elif query.data == "account":
        keyboard = [
            [InlineKeyboardButton("⬅ Back", callback_data="main")]
        ]
        await query.edit_message_text(
            f"User ID: {user_id}",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

    # ---------- TASK ----------
    elif query.data == "task":
        keyboard = [
            [InlineKeyboardButton("✅ Done Task", callback_data="done")],
            [InlineKeyboardButton("⬅ Back", callback_data="main")]
        ]
        await query.edit_message_text(
            "Complete task and press Done.",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

    elif query.data == "done":
        amount = 0.21
        holds[user_id] = (amount, time.time())
        save(HOLD_FILE, holds)

        # Referral commission (10%)
        if user_id in referrals:
            ref_id = referrals[user_id]
            balances[ref_id] = balances.get(ref_id, 0) + (amount * 0.1)
            save(BAL_FILE, balances)

        keyboard = [[InlineKeyboardButton("⬅ Back", callback_data="main")]]

        await query.edit_message_text(
            "Task submitted. Money in 3-day hold.",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

    # ---------- FINANCE ----------
    elif query.data == "finance":
        main_bal = balances.get(user_id, 0)
        hold = holds.get(user_id)

        msg = f"Main Balance: ${main_bal}"
        if hold:
            msg += f"\nHold: ${hold[0]}"

        keyboard = [
            [InlineKeyboardButton("Withdraw", callback_data="withdraw")],
            [InlineKeyboardButton("⬅ Back", callback_data="main")]
        ]

        await query.edit_message_text(
            msg,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

    elif query.data == "withdraw":
        if user_id not in holds:
            await query.answer("No hold balance")
            return

        amount, hold_time = holds[user_id]

        if time.time() - hold_time < 3*24*60*60:
            await query.answer("Still in 3-day hold")
            return

        balances[user_id] = balances.get(user_id, 0) + amount
        del holds[user_id]

        save(BAL_FILE, balances)
        save(HOLD_FILE, holds)

        await query.edit_message_text(
            "Withdraw completed.",
            reply_markup=main_menu()
        )

    # ---------- REFERRAL ----------
    elif query.data == "referral":
        link = f"https://t.me/{context.bot.username}?start={user_id}"
        keyboard = [[InlineKeyboardButton("⬅ Back", callback_data="main")]]

        await query.edit_message_text(
            f"Your referral link:\n{link}\n\nEarn 10% from referrals.",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

# ================= APP =================
app = ApplicationBuilder().token(TOKEN).build()

app.add_handler(CommandHandler("start", start))
app.add_handler(CallbackQueryHandler(button))

print("Bot running...")
app.run_polling()
